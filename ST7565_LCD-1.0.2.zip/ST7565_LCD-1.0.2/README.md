This is a library for ST7565 Monochrome LCD Display.

These display uses SPI to communicate with the Arduino board, 4 or 5 pins are required (chip select pin connection is optional, if not used then it should be connected to GND).

This is a free library WITH NO WARRANTY, use it at your own risk!

https://simple-circuit.com/

This library depends on Adafruit GFX library at:

https://github.com/adafruit/Adafruit-GFX-Library

being present on your system. Please make sure you have installed the latest version before using this library.

Website: https://simple-circuit.com/

Example URL:
